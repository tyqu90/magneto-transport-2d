# -*- coding: utf-8 -*-
"""
Created on Mon Apr 16 09:50:43 2018

@author: miche
"""





"""
The following function read the data file (.dat) and
create a Dataframe.
The data are ordered in columns with blank spacing. The
i-th column is called by data[[i]] 
"""



def data_reader(directory):
    """
    imput: path of the directory as a string (e.g. r"C:...")
           IMPORTANT: do not forget to put r before your file path
    output: Dataframe of measured points. The Dataframe has several columns,
            which are the measurement parameters.
    """
    import pandas as pd
    import os
    dataframe= []
    for filename in os.listdir(directory):
        if filename.endswith(".txt"):
            f= os.path.join(directory, filename)
            head = pd.read_csv(f,
                       sep='\s+', #blank separation
                       skiprows=1,
                       nrows = 1,
                       header=None,
                       skipinitialspace = True,
                       skip_blank_lines = True,
		       encoding='windows-1252')   
            name = head.values[0][0::2] #some_list[start:stop:step]
    for filename in os.listdir(directory):
        if filename.endswith(".dat"): 
            datafile = os.path.join(directory, filename)
            data = pd.read_csv(datafile,
                       sep='\s+', #blank separation
                       header=None,
                       names =name,
                       skipinitialspace = True,
                       skip_blank_lines = True)
            dataframe.append(data)
        else:
            continue
    return pd.concat(dataframe, ignore_index=True) #Return a Dataframe with all the measured points