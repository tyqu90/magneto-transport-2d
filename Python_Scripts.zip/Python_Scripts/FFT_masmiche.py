# -*- coding: utf-8 -*-
"""
Created on Mon Apr 30 12:08:49 2018

@author: miche
"""

"""
Fast Fourier Transform (FFT) 
"""
#_______________________________________________________

def FFT(xdata, ydata, zero_padding=10, windowing='hamming', power=False):
    from scipy.fftpack import fft, fftfreq
    from scipy import signal as sig
    import numpy as np
    """
    Imput:  xdata: nparray (N, 1), magnetic field, need to have constant 
                spacing
            ydata: nparray (N, 1), resistance, real sequence of data 
                points
            zero-padding: int, how many times of the 
                data's length should be the zero-padding             
            draw: True/False enable plot of Fourer 
                analysis
            windowing: function chosen for windowing 
                process. Allowed functions:
                blackman, hamming, hann, flattop
    Output: xf, yf
            xf frequencies
            yf power spectrum 
    """    
    N = len(xdata)
    spacing = np.mean(np.diff(xdata))
    
    #windowing
    if windowing == 'blackman':
        w = sig.blackman(N)
    elif windowing == 'hamming':
        w = sig.hamming(N)
    elif windowing == 'hann':
        w = sig.hann(N)
    elif windowing == 'flattop':
        w = sig.flattop(N)
    elif windowing=='none':
        w=np.tile(1, N)
    else:
        w = sig.hamming(N)
        print( 'ERROR:')
        print( 'Name of windowing not in the list.')
        print( 'Windowing was set to hamming')
    norm = np.sum(w)/N
    ydata = ydata*w/norm

    # Zero-padding
    length = N*zero_padding
    add_zero = np.zeros(length) 
    y = np.concatenate((add_zero, ydata, add_zero))#add zeros before and after the data

    N_new = N+2*length
    xf = fftfreq(N_new, spacing)[0:N_new//2-1]
    yf = abs(fft(y)[0:N_new//2-1]) *2/N

    if power == True:
        yf = yf**2
    else:
        pass
    return xf, yf

#==============================================================================
# 
#==============================================================================
"""
1D Fast Fourier Transform (FFT) of a 2D plot, line by line
"""
#_______________________________________________________

def FFT_(xdata, ydata, zdata, zero_padding=10, windowing='hamming'):
    from scipy.fftpack import fft, fftfreq
    from scipy import signal as sig
    import numpy as np
    """
    It compute the one dimensional FFT of (time domain, signal)
    for each value of ydata.
    Imput:  xdata (time domain): ndarray (M, N), it needs 
                to have constant spacing.
            ydata: ndarray (M,), second axis that determine
                the number of FFT to be compute.
            zdata (signal): ndarray (M, N), the oscillatory 
                signal as a function of the time domain that 
                need to be Fourier transformed.
            N is the length of the array to be analysed with fft
            M is the number of array to be analysed
            zero-padding: int, number of zeros to be added
                left and rigth to the original data.             
            windowing: function for zero convergence at the
                boundary. It suppress artefact peaks.
                Allowed functions:
                blackman, hamming, hann, flattop
    Output: XF, YF, ZF: ndarray (M, N')
            XF: frequency domain
            YF: additional axis
            ZF: Amplitude Spectrum
    """
    M, N = np.shape(xdata) #size of data set
    spacing = np.diff(xdata)[0,0] #spacing between data points
    #windowing
    if windowing == 'blackman':
        w = sig.blackman(N)
    elif windowing == 'hamming':
        w = sig.hamming(N)
    elif windowing == 'hann':
        w = sig.hann(N)
    elif windowing == 'flattop':
        w = sig.flattop(N)
    elif windowing == 'none':
        w = np.tile(1, N)
    else:
        w = sig.hamming(N)
        print( '!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
        print( 'ERROR:')
        print( 'Name of windowing not in the list.')
        print( 'Windowing was set to hamming')
    norm = np.sum(w)/N
    W = np.tile(w, (M,1))
    z = zdata * W / norm
    
    # Zero-padding
    L_zeros = N*zero_padding
    add_zero = np.zeros((M, L_zeros))
    z = np.concatenate((add_zero, z, add_zero), axis=1)#add zeros before and after the data
    
    # Fourier transform
    N_new = N+2*L_zeros
    if N%2 ==0:
        xf = fftfreq(N_new, spacing)[0:N_new//2-1]
        XF = np.tile(xf, (M,1))
        ZF = np.zeros( (M, len(xf)))
        for i in range(M):
            zf = fft(z[i,:])[0:N_new//2-1]
            ZF[i,:] = np.abs(zf)*2./N     
    else:
        xf = fftfreq(N_new, spacing)[0:N_new//2]
        XF = np.tile(xf, (M,1))
        ZF = np.zeros( (M, len(xf)))
        for i in range(M):
            zf = fft(z[i,:])[0:N_new//2]
            ZF[i,:] = np.abs(zf)*2./N
    # reshape the additional axis
    YF = np.tile(ydata, (np.shape(XF)[1],1)).T
    return XF, YF, ZF


'filter the background of the data'
def filtering(t, x, fc, btype, order=8):
    """
    in: t: measured time domain
        x: signal in the time domain
        fc: critical frequencies (e.g. cut-offfor low/high-pass 
            (int or length-2 sequence for band-pass)
        order: order of the filter (how fast it suppress the frequency)
        btype: {'lowpass', 'highpass', 'bandpass'}
    out: y: output of the digital filter (butterworth filter)   
    """
    from scipy import signal
    nyq = len(t)/(max(t)-min(t))
    W = fc / nyq
    b, a = signal.butter(order, W, btype, analog=False)
    y = signal.filtfilt(b, a, x)
    return y  

def FFT_SdH(B, R, Bmin, Bmax, V, filt=True, fc=0, zero_padding=10, windowing='hamming', index_max=0):
    """
    In: B: ndarray (magnetic field)
        R: ndarray (resistance)
        Bmin, Bmax: range of Bfield for the FFT analysis
        polynom_order: order of the polynomial bgr to be subtracted
        zero_padding: number zero padding
        windowing: kind of window to be used in the FFT
    Out: the density estimated from the period of the oscillations
    """
    import matplotlib.pyplot as plt
    import numpy as np
    import matplotlib.gridspec as gridspec
    'Plot'
    labsz = 30
    ticksz = 25
    gs = gridspec.GridSpec(3, 2)
    fig = plt.figure(figsize=(15,20))
    #___________________________________________________
    ax0 = fig.add_subplot(gs[0,:])
    ax0.set_title(r'Fourier analysis of SdH oscillations', size=labsz, y=1.03)
    ax0.set_xlabel(r'$B$ [T]', size=labsz)
    ax0.set_ylabel(r'$R_{xx}$ [$\Omega$]', size=labsz)
    ax0.tick_params(labelsize = ticksz)
    ax0.grid(True)    
    ax0.plot(B, R, '-b', lw=3, label=r'Data ($V_{g}=%.2f$ V)' %(V))
    ax0.legend(fontsize=labsz, loc='best')
    import matplotlib.transforms as mtransforms
    trans = mtransforms.blended_transform_factory(
            ax0.transData, ax0.transAxes)
    ax0.fill_between(B, 0, 1, where=(B>Bmin) & (B<Bmax), 
                     facecolor='red', alpha=0.5, 
                     transform=trans) 
    ax0.set_ylim(min(R), 
                 max(R)) 
    ax0.set_xlim(min(B), max(B))
    #___________________________________________________
    cond1 = B <= Bmax
    cond2 = B >= Bmin
    x = 1. / B[cond1 & cond2]
    y = R[cond1 & cond2]
    d = {'x':x, 'y':y}
    import pandas as pd
    df = pd.DataFrame(data=d).sort(columns=['x'])
    x = df['x']
    y = df['y']
    ax1 = fig.add_subplot(gs[1, 0])
    ax1.set_title(r'With background', 
          size=labsz, y=1.03)
    ax1.set_xlabel(r'$1/B$ [T$^{-1}$]', size=labsz)
    ax1.set_ylabel(r'$R_{xx}$ [$\Omega$]', size=labsz)
    ax1.tick_params(labelsize = ticksz)
    ax1.grid(lw=1)
    ax1.plot(x,y, 'b-', lw=3, label=r'Data')
    ax1.set_xlim(min(x), max(x))
    #___________________________________________________
    # subtract background
    if filt==True:    
        y1 = filtering(x, y, fc, btype='highpass', order=8)
        ax1.plot(x, (y-y1), '-r', lw=3, label='Background')
    else:
        y1 = y
    ax1.legend(fontsize=labsz, loc='best')
    ax2 = fig.add_subplot(gs[1, 1]) # row 0, col 1
    ax2.set_title('Without background', size=labsz, y=1.03)
    ax2.set_xlabel(r'$1/B$ [T$^{-1}$]', size=labsz)
    ax2.set_ylabel(r'$\Delta R_{xx}$ [$\Omega$]', size=labsz)
    ax2.tick_params(labelsize=ticksz)
    ax2.set_xlim(min(x), max(x))
    ax2.grid(lw=1)
    ax2.plot(x, y1, 'b-', lw=3, label=r'Data')
    deltax = np.diff(x)
    if deltax[0] != deltax[-1]:
        # Interpolation due to irregular step in 1/B
        from scipy.interpolate import spline
        x_spl = np.linspace(min(x), max(x), len(x))
        y_spl = spline(x, y1, xnew=x_spl, order = 3)
        ax2.plot(x_spl, y_spl, '--g', lw=3, label='Interpolation')
    else:
        x_spl = x
        y_spl = y
    ax2.legend(fontsize=labsz, loc='best')
    #___________________________________________________
    xf, yf = FFT(x, y1, 10, windowing=windowing)
    import scipy.constants as sc
    h = sc.physical_constants['Planck constant'][0]
    e = sc.physical_constants['elementary charge'][0]
    xf = xf*e/h #1/m^2
    ax3 = fig.add_subplot(gs[2, :])
    ax3.set_title(r'Fourier spectrum', size=labsz, y=1.03)
    ax3.set_xlabel('Density $n$ [$10^{15}$ m$^{-2}$]', size=labsz)
    ax3.set_ylabel('Amplitude spectrum $|F|$', size=labsz)
    ax3.tick_params(labelsize=25)
    ax3.plot(xf*1E-15, yf, 'b-', lw=3)
    from scipy.signal import argrelextrema
    L = len(index_max)
    if L == 1:
        imax  = argrelextrema(yf, np.greater)[0][index_max[0]] # local maxima
        ax3.plot([xf[imax]*1E-15, xf[imax]*1E-15], [0, yf[imax]], 'r-', lw=3, label=r'$n=$%s $\cdot 10^{15}$ m$^{-2}$' %np.round(xf[imax]*1E-15, decimals=3) )
    else:
        index=0
        for i in index_max:
            imax  = argrelextrema(yf, np.greater)[0][i] 
            c = ['green', 'red', 'black', 'yellow', 'blue', 'orange']
            ax3.plot([xf[imax]*1E-15, xf[imax]*1E-15], [0, yf[imax]], color=c[index], ls='-', lw=2, label=r'$n=$%s $\cdot 10^{15}$ m$^{-2}$' %np.round(xf[imax]*1E-15, decimals=3) )   
            index+=1
    ax3.legend(fontsize=labsz, loc='best')
    ax3.set_xlim(0, 20)
    plt.tight_layout()
    return xf[imax]
      
    
    
    
    
    
    
    
    
    
    
    
    