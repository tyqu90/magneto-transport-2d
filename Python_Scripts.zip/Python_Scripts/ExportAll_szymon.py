# -*- coding: utf-8 -*-


def exportData(path,
               stepData,
               logData,
               stepName,
               logName,
               stepUnit,
               logUnit,
               comment=''):
    import os
    fileName = os.path.basename(path)
    folderName = os.path.join(os.path.dirname(path), fileName)
    if not os.path.isdir(folderName):
        os.mkdir(folderName)
    """Export data from Log Viewer to file using custom format."""
    filePath = os.path.join(folderName, fileName+'log.txt')
    with open(filePath, 'w') as f:
        f.write('Channels:\n')
        for (name, unit) in zip(stepName, stepUnit):
            f.write('%s (%s)\t' % (name, unit))
        for (name, unit) in zip(logName, logUnit):
            f.write('%s (%s)\t' % (name, unit))
        f.write('\nComments:\n')
        f.write(comment)

    fdeb = open(filePath + '.debug.log', 'w')

    traceNumber = len(logData[0])
    steps = len(stepData)
    logs = len(logData)

    for t in range(0, traceNumber):
        fdeb.write('## trace ' + str(t)+'\n')
        points = len(logData[0][t])
        fdeb.write(str(points)+'\n')
        filePath = os.path.join(folderName, fileName+"%03d.dat" % t)
        with open(filePath, 'w') as f:
            fdeb.write('range: ' + str(range(0, points)) + '\n')
            for p in range(0, points):
                for s in range(0, steps):
                    f.write(str(stepData[s][t][p])+'\t')
                for l in range(0, logs-1):
                    f.write(str(logData[l][t][p])+'\t')
                fdeb.write('##' + str(t) + '-' + str(p) + '\n')
                fdeb.flush()
                fdeb.write(str(len(logData[-1][t]))+' vs ')
                fdeb.write(str(len(range(0, points)))+'\n')
                fdeb.write(str(logData[-1][t][p])+'\n')
                fdeb.flush()
                f.write(str(logData[-1][t][p])+'\n')
